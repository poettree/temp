import numpy as np
import pandas as pd
import re
import json
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from tkinter import Tk
from tkinter.filedialog import askopenfilename

# Open a file dialog to select the CSV file
Tk().withdraw()  # Hide the main Tk window
filename = askopenfilename(title="Select CSV file", filetypes=[("CSV files", "*.csv")])

# Load data from CSV file
df = pd.read_csv(filename)

# Extract x, y, z values from the 'location' column
def extract_coordinates(location_str):
    # Find all numbers in the format x####, y####, z####
    coords = re.findall(r'\d+', location_str)
    return [int(coord) for coord in coords]

# Apply extraction to the location column and create a new DataFrame with x, y, z columns
df[['x', 'y', 'z']] = df['location'].apply(lambda loc: pd.Series(extract_coordinates(loc)))
data = df[['x', 'y', 'z']].values

# Apply K-means clustering
kmeans = KMeans(n_clusters=3, random_state=0)
df['cluster'] = kmeans.fit_predict(data)

# Group data by clusters and format as specified
cluster_groups = df.groupby('cluster')['index'].apply(list).to_dict()

# Create the required JSON-like structure
groups = [[{"index": idx} for idx in indices] for indices in cluster_groups.values()]
output_data = {"groups": groups}

# Export to JSON file
with open("clusters_output.json", "w") as f:
    json.dump(output_data, f, indent=4)

print("Exported cluster groups to clusters_output.json")

# Plotting the 3D data with clusters
fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')
scatter = ax.scatter(data[:, 0], data[:, 1], data[:, 2], c=df['cluster'], cmap='viridis', marker='o')

# Plot centroids
centroids = kmeans.cluster_centers_
ax.scatter(centroids[:, 0], centroids[:, 1], centroids[:, 2], c='red', s=200, marker='X', label='Centroids')

# Add labels and legend
ax.set_title("3D K-means Clustering")
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")
plt.legend()
plt.show()
